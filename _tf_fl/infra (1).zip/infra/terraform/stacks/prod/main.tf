locals {
  prefix = lower(replace("${var.PROJECT_NAME}-${var.ENVIRONMENT}", "_", "-"))

  common_tags = merge(var.TAGS, {
    environment = var.ENVIRONMENT
    managed_by  = "terraform"
    project     = var.PROJECT_NAME
  })
}

data "azurerm_resource_group" "main" {
  name = var.RESOURCE_GROUP_NAME
}

resource "azurerm_user_assigned_identity" "data_ingest_uami" {
  name                = "uami-${local.prefix}"
  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name
  tags                = local.common_tags
}

module "function_storage" {
  source = "../../modules/storage-account"

  name                     = substr(replace("sa${var.PROJECT_NAME}${var.ENVIRONMENT}func", "-", ""), 0, 24)
  resource_group_name      = data.azurerm_resource_group.main.name
  location                 = data.azurerm_resource_group.main.location
  account_tier             = var.FUNCTION_STORAGE_ACCOUNT_TIER
  account_replication_type = var.FUNCTION_STORAGE_ACCOUNT_REPLICATION_TYPE
  container_names          = ["function-packages"]
  tags                     = local.common_tags
}

module "backend_storage" {
  source = "../../modules/storage-account"

  name                     = substr(replace("sa${var.PROJECT_NAME}${var.ENVIRONMENT}app", "-", ""), 0, 24)
  resource_group_name      = data.azurerm_resource_group.main.name
  location                 = data.azurerm_resource_group.main.location
  account_tier             = var.BACKEND_STORAGE_ACCOUNT_TIER
  account_replication_type = var.BACKEND_STORAGE_ACCOUNT_REPLICATION_TYPE
  container_names          = ["fx-inbox", "fx-processed", "fx-csv", "fx-errors"]
  tags                     = local.common_tags
}

module "key_vault" {
  source = "../../modules/key-vault"

  name                       = substr(replace("kv-${local.prefix}", "_", "-"), 0, 24)
  resource_group_name        = data.azurerm_resource_group.main.name
  location                   = data.azurerm_resource_group.main.location
  tenant_id                  = var.TENANT_ID
  sku_name                   = var.KEY_VAULT_SKU_NAME
  purge_protection_enabled   = var.KEY_VAULT_PURGE_PROTECTION_ENABLED
  soft_delete_retention_days = 90
  tags                       = local.common_tags
}

module "function_app" {
  source = "../../modules/function-app"

  name                             = "func-${local.prefix}"
  location                         = data.azurerm_resource_group.main.location
  resource_group_name              = data.azurerm_resource_group.main.name
  service_plan_name                = "asp-${local.prefix}"
  service_plan_sku_name            = var.SERVICE_PLAN_SKU_NAME
  storage_container_endpoint       = "${module.function_storage.primary_blob_endpoint}function-packages"
  user_assigned_identity_id        = azurerm_user_assigned_identity.data_ingest_uami.id
  user_assigned_identity_client_id = azurerm_user_assigned_identity.data_ingest_uami.client_id
  application_insights_name        = "appi-${local.prefix}"
  log_analytics_workspace_name     = "log-${local.prefix}"
  functions_extension_version      = var.FUNCTIONS_EXTENSION_VERSION
  function_runtime                 = var.FUNCTION_RUNTIME
  function_runtime_version         = var.FUNCTION_RUNTIME_VERSION
  maximum_instance_count           = var.FUNCTION_MAXIMUM_INSTANCE_COUNT
  instance_memory_in_mb            = var.FUNCTION_INSTANCE_MEMORY_IN_MB
  enable_builtin_logging           = var.ENABLE_BUILTIN_LOGGING
  enable_auth                      = var.ENABLE_AUTH
  auth_client_id                   = var.AUTH_CLIENT_ID
  auth_client_secret_setting_name  = var.AUTH_CLIENT_SECRET_SETTING_NAME
  auth_allowed_audiences           = var.AUTH_ALLOWED_AUDIENCES
  key_vault_uri                    = module.key_vault.vault_uri
  tags                             = local.common_tags

  depends_on = [
    # azurerm_role_assignment.function_storage_blob_data_contributor
  ]
}
