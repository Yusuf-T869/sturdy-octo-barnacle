output "resource_group_name" {
  description = "Resource group containing the shared resources."
  value       = data.azurerm_resource_group.main.name
}

output "terraform_backend_storage_account_id" {
  description = "Resource ID of the shared storage account used for Terraform backend state."
  value       = module.snowflake_tf_backend_storage.id
}

output "terraform_backend_storage_account_name" {
  description = "Name of the shared storage account used for Terraform backend state."
  value       = module.snowflake_tf_backend_storage.name
}

output "terraform_backend_container_name" {
  description = "Blob container name used for Terraform backend state."
  value       = var.state_container_name
}

output "key_vault_id" {
  description = "Resource ID of the shared Key Vault."
  value       = module.key_vault.id
}

output "key_vault_name" {
  description = "Name of the shared Key Vault."
  value       = module.key_vault.name
}

output "key_vault_uri" {
  description = "Vault URI for the shared Key Vault."
  value       = module.key_vault.vault_uri
}

output "ingest_uami_id" {
  description = "Resource ID of the ingest user-assigned managed identity."
  value       = module.ingest_identity.id
}

output "ingest_uami_name" {
  description = "Name of the ingest user-assigned managed identity."
  value       = module.ingest_identity.name
}

output "ingest_uami_principal_id" {
  description = "Principal ID of the ingest user-assigned managed identity."
  value       = module.ingest_identity.principal_id
}

output "ingest_uami_client_id" {
  description = "Client ID of the ingest user-assigned managed identity."
  value       = module.ingest_identity.client_id
}

output "egress_uami_id" {
  description = "Resource ID of the egress user-assigned managed identity."
  value       = module.egress_identity.id
}

output "egress_uami_name" {
  description = "Name of the egress user-assigned managed identity."
  value       = module.egress_identity.name
}

output "egress_uami_principal_id" {
  description = "Principal ID of the egress user-assigned managed identity."
  value       = module.egress_identity.principal_id
}

output "egress_uami_client_id" {
  description = "Client ID of the egress user-assigned managed identity."
  value       = module.egress_identity.client_id
}
