variable "name" {
  description = "Azure Container App name."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group containing the Azure Container App."
  type        = string
}

variable "container_app_environment_id" {
  description = "Azure Container Apps environment resource ID."
  type        = string
}

variable "user_assigned_identity_id" {
  description = "User-assigned managed identity resource ID attached to the Container App."
  type        = string
}

variable "revision_mode" {
  description = "Container App revision mode."
  type        = string
  default     = "Single"
}

variable "workload_profile_name" {
  description = "Container App workload profile name."
  type        = string
  default     = "Consumption"
}

variable "container_name" {
  description = "Name of the container in the Container App template."
  type        = string
}

variable "image" {
  description = "Container image reference."
  type        = string
}

variable "cpu" {
  description = "vCPU allocated to the Container App container."
  type        = number
  default     = 0.5
}

variable "memory" {
  description = "Memory allocated to the Container App container."
  type        = string
  default     = "1Gi"
}

variable "min_replicas" {
  description = "Minimum Container App replicas."
  type        = number
  default     = 1
}

variable "max_replicas" {
  description = "Maximum Container App replicas."
  type        = number
  default     = 1
}

variable "env_vars" {
  description = "Plain-text environment variables injected into the Container App."
  type        = map(string)
  default     = {}
}

variable "registry_server" {
  description = "Optional registry server used by the Container App."
  type        = string
  default     = null
  nullable    = true
}

variable "registry_identity" {
  description = "Optional user-assigned identity resource ID used for Container App registry auth."
  type        = string
  default     = null
  nullable    = true
}

variable "tags" {
  description = "Resource tags."
  type        = map(string)
  default     = {}
}
