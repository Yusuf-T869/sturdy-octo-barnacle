locals {
  prefix = lower(replace("${var.PROJECT_NAME}-${var.ENVIRONMENT}", "_", "-"))

  common_tags = merge(var.TAGS, {
    environment = var.ENVIRONMENT
    managed_by  = "terraform"
    project     = var.PROJECT_NAME
    stack       = "finxact"
  })

  function_storage_account_name = substr(replace(lower("sa${local.prefix}func"), "-", ""), 0, 24)
  data_storage_account_name     = substr(replace(lower("sa${local.prefix}data"), "-", ""), 0, 24)
  # container_registry_name       = substr(replace(lower(var.CONTAINER_REGISTRY_NAME), "-", ""), 0, 50)
}

data "terraform_remote_state" "shared" {
  backend = "azurerm"

  config = {
    resource_group_name  = var.state_resource_group_name
    storage_account_name = var.state_storage_account_name
    container_name       = var.state_container_name
    key                  = var.state_key
    use_azuread_auth     = true
  }
}

data "azurerm_resource_group" "main" {
  name = var.RESOURCE_GROUP_NAME
}

# data "azurerm_container_app_environment" "main" {
#   name                = var.CONTAINER_APP_ENVIRONMENT_NAME
#   resource_group_name = var.CONTAINER_APP_ENVIRONMENT_RESOURCE_GROUP_NAME
# }

module "function_storage" {
  source = "../../modules/storage-account"

  name                     = local.function_storage_account_name
  resource_group_name      = data.azurerm_resource_group.main.name
  location                 = data.azurerm_resource_group.main.location
  account_tier             = var.FUNCTION_STORAGE_ACCOUNT_TIER
  account_replication_type = var.FUNCTION_STORAGE_ACCOUNT_REPLICATION_TYPE
  container_names          = ["function-packages"]
  tags                     = local.common_tags
}

module "data_storage" {
  source = "../../modules/storage-account"

  name                     = local.data_storage_account_name
  resource_group_name      = data.azurerm_resource_group.main.name
  location                 = data.azurerm_resource_group.main.location
  account_tier             = var.DATA_STORAGE_ACCOUNT_TIER
  account_replication_type = var.DATA_STORAGE_ACCOUNT_REPLICATION_TYPE
  container_names          = ["finxact-inbox", "finxact-processed", "finxact-errors"]
  tags                     = local.common_tags
}

# module "container_registry" {
#   source = "../../modules/container-registry"

#   name                = local.container_registry_name
#   resource_group_name = data.azurerm_resource_group.main.name
#   location            = data.azurerm_resource_group.main.location
#   sku                 = var.CONTAINER_REGISTRY_SKU
#   tags                = local.common_tags
# }

resource "azurerm_role_assignment" "ingest_function_storage_blob_data_contributor" {
  scope                = module.function_storage.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = data.terraform_remote_state.shared.outputs.ingest_uami_principal_id
}

resource "azurerm_role_assignment" "ingest_data_storage_blob_data_contributor" {
  scope                = module.data_storage.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = data.terraform_remote_state.shared.outputs.ingest_uami_principal_id
}

resource "azurerm_role_assignment" "egress_function_storage_blob_data_contributor" {
  scope                = module.function_storage.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = data.terraform_remote_state.shared.outputs.egress_uami_principal_id
}

resource "azurerm_role_assignment" "egress_data_storage_blob_data_contributor" {
  scope                = module.data_storage.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = data.terraform_remote_state.shared.outputs.egress_uami_principal_id
}

# resource "azurerm_role_assignment" "ingest_acr_pull" {
#   scope                = module.container_registry.id
#   role_definition_name = "AcrPull"
#   principal_id         = data.terraform_remote_state.shared.outputs.ingest_uami_principal_id
# }

# resource "azurerm_role_assignment" "ingest_acr_repository_contributor" {
#   scope                = module.container_registry.id
#   role_definition_name = "Container Registry Repository Contributor"
#   principal_id         = data.terraform_remote_state.shared.outputs.ingest_uami_principal_id
# }

# resource "azurerm_role_assignment" "ingest_acr_repository_catalog_lister" {
#   scope                = module.container_registry.id
#   role_definition_name = "Container Registry Repository Catalog Lister"
#   principal_id         = data.terraform_remote_state.shared.outputs.ingest_uami_principal_id
# }

module "function_app" {
  source = "../../modules/function-app"

  name                             = "func-${local.prefix}"
  location                         = data.azurerm_resource_group.main.location
  resource_group_name              = data.azurerm_resource_group.main.name
  service_plan_name                = "asp-${local.prefix}"
  service_plan_sku_name            = var.SERVICE_PLAN_SKU_NAME
  storage_container_endpoint       = "${module.function_storage.primary_blob_endpoint}function-packages"
  user_assigned_identity_id        = data.terraform_remote_state.shared.outputs.egress_uami_id
  user_assigned_identity_client_id = data.terraform_remote_state.shared.outputs.egress_uami_client_id
  application_insights_name        = "appi-${local.prefix}"
  log_analytics_workspace_name     = "log-${local.prefix}"
  functions_extension_version      = var.FUNCTIONS_EXTENSION_VERSION
  function_runtime                 = var.FUNCTION_RUNTIME
  function_runtime_version         = var.FUNCTION_RUNTIME_VERSION
  maximum_instance_count           = var.FUNCTION_MAXIMUM_INSTANCE_COUNT
  instance_memory_in_mb            = var.FUNCTION_INSTANCE_MEMORY_IN_MB
  additional_app_settings          = var.FUNCTION_APP_SETTINGS
  enable_builtin_logging           = var.ENABLE_BUILTIN_LOGGING
  enable_auth                      = var.ENABLE_AUTH
  auth_client_id                   = var.AUTH_CLIENT_ID
  auth_client_secret_setting_name  = var.AUTH_CLIENT_SECRET_SETTING_NAME
  auth_allowed_audiences           = var.AUTH_ALLOWED_AUDIENCES
  key_vault_uri                    = data.terraform_remote_state.shared.outputs.key_vault_uri
  tags                             = local.common_tags

  depends_on = [
    azurerm_role_assignment.egress_function_storage_blob_data_contributor
  ]
}

# module "container_app" {
#   source = "../../modules/container-app"

#   name                         = var.CONTAINER_APP_NAME
#   resource_group_name          = data.azurerm_resource_group.main.name
#   container_app_environment_id = data.azurerm_container_app_environment.main.id
#   user_assigned_identity_id    = data.terraform_remote_state.shared.outputs.ingest_uami_id
#   revision_mode                = var.CONTAINER_APP_REVISION_MODE
#   container_name               = var.CONTAINER_APP_CONTAINER_NAME
#   image = var.CONTAINER_APP_IMAGE != null ? var.CONTAINER_APP_IMAGE : (
#     var.CONTAINER_APP_USE_ACR_REGISTRY ? "${module.container_registry.login_server}/${var.CONTAINER_REGISTRY_REPOSITORY_NAME}:${var.CONTAINER_APP_IMAGE_TAG}" : var.CONTAINER_APP_PLACEHOLDER_IMAGE
#   )
#   cpu      = var.CONTAINER_APP_CPU
#   memory   = var.CONTAINER_APP_MEMORY
#   env_vars = var.CONTAINER_APP_ENV_VARS

#   registry_server   = var.CONTAINER_APP_USE_ACR_REGISTRY ? module.container_registry.login_server : null
#   registry_identity = var.CONTAINER_APP_USE_ACR_REGISTRY ? data.terraform_remote_state.shared.outputs.ingest_uami_id : null
#   tags              = local.common_tags
# }

# resource "azurerm_role_assignment" "ingest_container_apps_contributor" {
#   scope                = module.container_app.id
#   role_definition_name = "Container Apps Contributor"
#   principal_id         = data.terraform_remote_state.shared.outputs.ingest_uami_principal_id
# }
