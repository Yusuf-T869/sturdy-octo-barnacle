variable "TENANT_ID" {
  description = "Azure Entra tenant ID. Optional when Terraform should use the current Azure CLI context."
  type        = string
  default     = null
  nullable    = true
}

variable "RESOURCE_GROUP_NAME" {
  description = "Name of the existing resource group where Savana resources will be created."
  type        = string
}

variable "ENVIRONMENT" {
  description = "Short environment name, for example dev or prod."
  type        = string
}

variable "PROJECT_NAME" {
  description = "Project or workload name used in resource naming."
  type        = string
}

variable "state_resource_group_name" {
  description = "Resource group containing the remote state storage account for the shared stack."
  type        = string
}

variable "state_storage_account_name" {
  description = "Storage account name containing the remote state for the shared stack."
  type        = string
}

variable "state_container_name" {
  description = "Blob container name containing the remote state for the shared stack."
  type        = string
  default     = "tfstate"
}

variable "state_key" {
  description = "Blob key of the shared stack remote state file."
  type        = string
}

variable "TAGS" {
  description = "Common tags applied to resources."
  type        = map(string)
  default     = {}
}

variable "FUNCTION_STORAGE_ACCOUNT_NAME" {
  description = "Optional name for the Azure Function runtime storage account."
  type        = string
  default     = null
  nullable    = true
}

variable "FUNCTION_STORAGE_ACCOUNT_TIER" {
  description = "Storage account tier used by the Azure Function."
  type        = string
  default     = "Standard"
}

variable "FUNCTION_STORAGE_ACCOUNT_REPLICATION_TYPE" {
  description = "Replication type for the Function App storage account."
  type        = string
  default     = "LRS"
}

variable "DATA_STORAGE_ACCOUNT_NAME" {
  description = "Optional name for the Savana application data storage account."
  type        = string
  default     = null
  nullable    = true
}

variable "DATA_STORAGE_ACCOUNT_TIER" {
  description = "Storage account tier used by the Savana application data storage account."
  type        = string
  default     = "Standard"
}

variable "DATA_STORAGE_ACCOUNT_REPLICATION_TYPE" {
  description = "Replication type for the Savana application data storage account."
  type        = string
  default     = "LRS"
}

variable "DATA_CONTAINER_NAMES" {
  description = "Blob containers to create for Savana data."
  type        = list(string)
  default     = ["inbox", "processed", "csv", "errors"]
}

variable "SERVICE_PLAN_SKU_NAME" {
  description = "SKU for the Function App service plan."
  type        = string
  default     = "FC1"
}

variable "FUNCTIONS_EXTENSION_VERSION" {
  description = "Azure Functions runtime version."
  type        = string
  default     = "~4"
}

variable "FUNCTION_RUNTIME" {
  description = "Function worker runtime."
  type        = string
  default     = "python"
}

variable "FUNCTION_RUNTIME_VERSION" {
  description = "Language runtime version for the Function App."
  type        = string
  default     = "3.12"
}

variable "FUNCTION_MAXIMUM_INSTANCE_COUNT" {
  description = "Maximum number of Flex Consumption instances."
  type        = number
  default     = 50
}

variable "FUNCTION_INSTANCE_MEMORY_IN_MB" {
  description = "Memory size in MB for each Flex Consumption instance."
  type        = number
  default     = 2048
}

variable "FUNCTION_APP_SETTINGS" {
  description = "Additional Function App settings."
  type        = map(string)
  default     = {}
}

variable "ENABLE_BUILTIN_LOGGING" {
  description = "Whether builtin filesystem logging should be enabled."
  type        = bool
  default     = false
}

variable "ENABLE_AUTH" {
  description = "Whether Azure App Service authentication should be enabled."
  type        = bool
  default     = false
}

variable "AUTH_CLIENT_ID" {
  description = "Client ID for the Entra ID app registration used by Easy Auth."
  type        = string
  default     = null
  nullable    = true
}

variable "AUTH_CLIENT_SECRET_SETTING_NAME" {
  description = "App setting name that contains the Entra ID client secret."
  type        = string
  default     = null
  nullable    = true
}

variable "AUTH_ALLOWED_AUDIENCES" {
  description = "Allowed token audiences for Function App auth."
  type        = list(string)
  default     = []
}
