# resource "azurerm_role_assignment" "function_key_vault_secrets_user" {
#   scope                = module.key_vault.id
#   role_definition_name = "Key Vault Secrets User"
#   principal_id         = azurerm_user_assigned_identity.data_ingest_uami.principal_id
# }

resource "azurerm_role_assignment" "function_website_contributor" {
  scope                = module.function_app.id
  role_definition_name = "Website Contributor"
  principal_id         = azurerm_user_assigned_identity.data_ingest_uami.principal_id
}

# resource "azurerm_role_assignment" "function_storage_blob_data_contributor" {
#   scope                = module.function_storage.id
#   role_definition_name = "Storage Blob Data Contributor"
#   principal_id         = azurerm_user_assigned_identity.data_ingest_uami.principal_id
# }

# resource "azurerm_role_assignment" "container_registry_acr_pull" {
#   scope                = azurerm_container_registry.main.id
#   role_definition_name = "AcrPull"
#   principal_id         = azurerm_user_assigned_identity.data_ingest_uami.principal_id
# }

# resource "azurerm_role_assignment" "container_registry_repository_contributor" {
#   scope                = azurerm_container_registry.main.id
#   role_definition_name = "Container Registry Repository Contributor"
#   principal_id         = azurerm_user_assigned_identity.data_ingest_uami.principal_id
# }

# resource "azurerm_role_assignment" "container_registry_repository_catalog_lister" {
#   scope                = azurerm_container_registry.main.id
#   role_definition_name = "Container Registry Repository Catalog Lister"
#   principal_id         = azurerm_user_assigned_identity.data_ingest_uami.principal_id
# }

# resource "azurerm_role_assignment" "container_app_contributor" {
#   scope                = azurerm_container_app.main.id
#   role_definition_name = "Container Apps Contributor"
#   principal_id         = azurerm_user_assigned_identity.data_ingest_uami.principal_id
# }
