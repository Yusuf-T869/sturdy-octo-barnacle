variable "subscription_id" {
  description = "Azure subscription ID. Optional when Terraform should use the current Azure CLI context."
  type        = string
  default     = null
  nullable    = true
}

variable "tenant_id" {
  description = "Azure Entra tenant ID. Optional when Terraform should use the current Azure CLI context."
  type        = string
  default     = null
  nullable    = true
}

variable "location" {
  description = "Deprecated for bootstrap storage deployment. The existing resource group's location is used."
  type        = string
  default     = null
  nullable    = true
}

variable "state_resource_group_name" {
  description = "Existing resource group name where Terraform state resources will be created."
  type        = string
}

variable "state_storage_account_name" {
  description = "Globally unique storage account name for Terraform state."
  type        = string
}

variable "state_container_name" {
  description = "Blob container name used for Terraform state."
  type        = string
  default     = "tfstate"
}

variable "tags" {
  description = "Tags for the Terraform state resources."
  type        = map(string)
  default     = {}
}
