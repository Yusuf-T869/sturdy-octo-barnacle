variable "TENANT_ID" {
  description = "Azure Entra tenant ID. Optional when Terraform should use the current Azure CLI context."
  type        = string
  default     = null
  nullable    = true
}

variable "RESOURCE_GROUP_NAME" {
  description = "Name of the existing resource group where shared resources will be created."
  type        = string
}

variable "ENVIRONMENT" {
  description = "Short environment name, for example dev or prod."
  type        = string
}

variable "PROJECT_NAME" {
  description = "Project or workload name used in resource naming."
  type        = string
}

variable "TAGS" {
  description = "Common tags applied to resources."
  type        = map(string)
  default     = {}
}

variable "state_container_name" {
  description = "Blob container name used for Terraform state."
  type        = string
  default     = "tfstate"
}

variable "state_storage_account_tier" {
  description = "Storage account tier used by the shared Terraform backend storage account."
  type        = string
  default     = "Standard"
}

variable "state_storage_account_replication_type" {
  description = "Replication type for the shared Terraform backend storage account."
  type        = string
  default     = "LRS"
}

variable "KEY_VAULT_SKU_NAME" {
  description = "SKU for Key Vault."
  type        = string
  default     = "standard"
}

variable "KEY_VAULT_PURGE_PROTECTION_ENABLED" {
  description = "Whether purge protection should be enabled on Key Vault."
  type        = bool
  default     = true
}
