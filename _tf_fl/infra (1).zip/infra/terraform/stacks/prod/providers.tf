terraform {
  required_version = ">= 1.6.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.26"
    }
    # azuredevops = {
    #   source  = "microsoft/azuredevops"
    #   version = "~> 1.15"
    # }
  }

  backend "local" {}
}

provider "azurerm" {
  features {}

  # subscription_id = var.SUBSCRIPTION_ID
  tenant_id = var.TENANT_ID
}

# provider "azuredevops" {
#   org_service_url       = var.AZDO_ORG_SERVICE_URL
#   personal_access_token = var.AZDO_PERSONAL_ACCESS_TOKEN
# }
