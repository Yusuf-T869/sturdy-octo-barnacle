terraform {
  required_version = ">= 1.6.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.26"
    }
  }
}

provider "azurerm" {
  features {}

  subscription_id = var.SUBSCRIPTION_ID
  tenant_id       = var.TENANT_ID
}
