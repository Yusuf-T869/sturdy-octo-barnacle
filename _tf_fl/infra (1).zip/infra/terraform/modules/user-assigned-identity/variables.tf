variable "name" {
  description = "User-assigned managed identity name."
  type        = string
}

variable "location" {
  description = "Azure region for the user-assigned managed identity."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group containing the user-assigned managed identity."
  type        = string
}

variable "tags" {
  description = "Resource tags."
  type        = map(string)
  default     = {}
}
