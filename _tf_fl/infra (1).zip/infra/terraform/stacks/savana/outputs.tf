output "resource_group_name" {
  description = "Resource group containing the Savana resources."
  value       = data.azurerm_resource_group.main.name
}

output "function_app_name" {
  description = "Name of the deployed Savana Azure Function App."
  value       = module.function_app.name
}

output "function_app_default_hostname" {
  description = "Default hostname for the Savana Function App."
  value       = module.function_app.default_hostname
}

output "function_storage_account_name" {
  description = "Storage account used by the Savana Azure Function runtime."
  value       = module.function_storage.name
}

output "data_storage_account_name" {
  description = "Storage account used for Savana application data."
  value       = module.data_storage.name
}
