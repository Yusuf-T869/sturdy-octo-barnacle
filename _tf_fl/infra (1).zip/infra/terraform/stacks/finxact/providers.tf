terraform {
  required_version = ">= 1.6.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.26"
    }
  }

  backend "local" {}
}

provider "azurerm" {
  features {}

  tenant_id = var.TENANT_ID
}
