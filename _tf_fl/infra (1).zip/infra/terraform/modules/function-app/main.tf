locals {
  flex_runtime_name = var.function_runtime == "dotnet" ? "dotnet-isolated" : var.function_runtime

  # Flex Consumption tracks Application Insights through site_config; duplicating
  # those values in app_settings causes persistent plan drift after apply.
  default_app_settings = {
    FUNCTIONS_EXTENSION_VERSION = var.functions_extension_version
    KEY_VAULT_URI               = var.key_vault_uri
    AZURE_CLIENT_ID             = var.user_assigned_identity_client_id
  }
}

resource "azurerm_service_plan" "this" {
  name                = var.service_plan_name
  location            = var.location
  resource_group_name = var.resource_group_name
  os_type             = "Linux"
  sku_name            = var.service_plan_sku_name

  tags = var.tags
}

resource "azurerm_log_analytics_workspace" "this" {
  name                = var.log_analytics_workspace_name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "PerGB2018"
  retention_in_days   = 30

  tags = var.tags
}

resource "azurerm_application_insights" "this" {
  name                = var.application_insights_name
  location            = var.location
  resource_group_name = var.resource_group_name
  workspace_id        = azurerm_log_analytics_workspace.this.id
  application_type    = "web"

  tags = var.tags
}

resource "azurerm_function_app_flex_consumption" "this" {
  name                              = var.name
  location                          = var.location
  resource_group_name               = var.resource_group_name
  service_plan_id                   = azurerm_service_plan.this.id
  storage_container_type            = "blobContainer"
  storage_container_endpoint        = var.storage_container_endpoint
  storage_authentication_type       = "UserAssignedIdentity"
  storage_user_assigned_identity_id = var.user_assigned_identity_id
  runtime_name                      = local.flex_runtime_name
  runtime_version                   = var.function_runtime_version
  maximum_instance_count            = var.maximum_instance_count
  instance_memory_in_mb             = var.instance_memory_in_mb

  identity {
    type         = "UserAssigned"
    identity_ids = [var.user_assigned_identity_id]
  }

  site_config {
    application_insights_connection_string = azurerm_application_insights.this.connection_string
    application_insights_key               = azurerm_application_insights.this.instrumentation_key
    http2_enabled                          = true
    use_32_bit_worker                      = false
  }

  app_settings = merge(local.default_app_settings, var.additional_app_settings)

  dynamic "auth_settings_v2" {
    for_each = var.enable_auth ? [1] : []

    content {
      auth_enabled           = true
      require_authentication = true
      unauthenticated_action = "Return401"
      default_provider       = "azureactivedirectory"

      active_directory_v2 {
        client_id                  = var.auth_client_id
        tenant_auth_endpoint       = "https://login.microsoftonline.com/${data.azurerm_client_config.current.tenant_id}/v2.0"
        client_secret_setting_name = var.auth_client_secret_setting_name
        allowed_audiences          = var.auth_allowed_audiences
      }

      login {}
    }
  }

  tags = var.tags
}

data "azurerm_client_config" "current" {}
