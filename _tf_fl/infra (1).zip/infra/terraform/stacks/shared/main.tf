locals {
  prefix = lower(replace("${var.PROJECT_NAME}-${var.ENVIRONMENT}", "_", "-"))

  common_tags = merge(var.TAGS, {
    environment = var.ENVIRONMENT
    managed_by  = "terraform"
    project     = var.PROJECT_NAME
    stack       = "shared"
  })

  ingest_uami_name = "uami-${local.prefix}-ingest"
  egress_uami_name = "uami-${local.prefix}-egress"

}

data "azurerm_client_config" "current" {}

data "azurerm_resource_group" "main" {
  name = var.RESOURCE_GROUP_NAME
}

module "snowflake_tf_backend_storage" {
  source = "../../modules/storage-account"

  name                     = substr(replace(lower("satfbackend${local.prefix}"), "-", ""), 0, 24)
  resource_group_name      = data.azurerm_resource_group.main.name
  location                 = data.azurerm_resource_group.main.location
  account_tier             = var.state_storage_account_tier
  account_replication_type = var.state_storage_account_replication_type
  container_names          = ["snowflake-tf-backend"]
  tags                     = local.common_tags
}


module "key_vault" {
  source = "../../modules/key-vault"

  name                       = "kvlt-${local.prefix}"
  resource_group_name        = data.azurerm_resource_group.main.name
  location                   = data.azurerm_resource_group.main.location
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  sku_name                   = var.KEY_VAULT_SKU_NAME
  purge_protection_enabled   = var.KEY_VAULT_PURGE_PROTECTION_ENABLED
  soft_delete_retention_days = 90
  tags                       = local.common_tags
}

module "ingest_identity" {
  source = "../../modules/user-assigned-identity"

  name                = local.ingest_uami_name
  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name
  tags                = local.common_tags
}

module "egress_identity" {
  source = "../../modules/user-assigned-identity"

  name                = local.egress_uami_name
  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name
  tags                = local.common_tags
}

resource "azurerm_role_assignment" "egress_key_vault_secrets_user" {
  scope                = module.key_vault.id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = module.egress_identity.principal_id
}
