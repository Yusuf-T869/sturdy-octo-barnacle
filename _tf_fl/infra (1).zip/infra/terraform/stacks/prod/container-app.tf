locals {
  container_registry_name = substr(
    replace(
      lower(coalesce(var.CONTAINER_REGISTRY_NAME, "acr${var.PROJECT_NAME}${var.ENVIRONMENT}")),
      "-",
      ""
    ),
    0,
    50
  )

  container_app_name = coalesce(var.CONTAINER_APP_NAME, "ca-${local.prefix}")
  container_app_image = coalesce(
    var.CONTAINER_APP_IMAGE,
    var.CONTAINER_APP_PLACEHOLDER_IMAGE
  )
}

data "azurerm_container_app_environment" "existing" {
  name                = var.CONTAINER_APP_ENVIRONMENT_NAME
  resource_group_name = var.CONTAINER_APP_ENVIRONMENT_RESOURCE_GROUP_NAME
}

resource "azurerm_container_registry" "main" {
  name                = local.container_registry_name
  resource_group_name = data.azurerm_resource_group.main.name
  location            = data.azurerm_resource_group.main.location
  sku                 = var.CONTAINER_REGISTRY_SKU
  tags                = local.common_tags
}

resource "azurerm_container_app" "main" {
  name                         = local.container_app_name
  resource_group_name          = data.azurerm_resource_group.main.name
  container_app_environment_id = data.azurerm_container_app_environment.existing.id
  revision_mode                = var.CONTAINER_APP_REVISION_MODE
  # Azure reports Consumption back on the resource; setting it explicitly avoids
  # a persistent "Consumption -> null" plan drift on subsequent runs.
  workload_profile_name = "Consumption"
  tags                  = local.common_tags

  identity {
    type         = "UserAssigned"
    identity_ids = [azurerm_user_assigned_identity.data_ingest_uami.id]
  }

  # registry {
  #   server   = azurerm_container_registry.main.login_server
  #   identity = azurerm_user_assigned_identity.data_ingest_uami.id
  # }

  template {
    min_replicas = var.CONTAINER_APP_MIN_REPLICAS
    max_replicas = var.CONTAINER_APP_MAX_REPLICAS

    container {
      name   = var.CONTAINER_APP_CONTAINER_NAME
      image  = local.container_app_image
      cpu    = var.CONTAINER_APP_CPU
      memory = var.CONTAINER_APP_MEMORY

      dynamic "env" {
        for_each = var.CONTAINER_APP_ENV_VARS
        content {
          name  = env.key
          value = env.value
        }
      }
    }
  }

  lifecycle {
    ignore_changes = [
      template[0].container[0].image
    ]
  }

  depends_on = [
    # azurerm_role_assignment.container_registry_acr_pull,
    # azurerm_role_assignment.container_registry_repository_contributor,
    # azurerm_role_assignment.container_registry_repository_catalog_lister,
  ]
}
