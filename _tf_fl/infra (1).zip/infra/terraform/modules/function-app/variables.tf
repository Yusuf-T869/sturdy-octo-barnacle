variable "name" {
  description = "Function App name."
  type        = string
}

variable "location" {
  description = "Azure region for the Function App."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group containing the Function App."
  type        = string
}

variable "service_plan_name" {
  description = "Function App hosting plan name."
  type        = string
}

variable "service_plan_sku_name" {
  description = "Function App hosting plan SKU."
  type        = string
  default     = "FC1"
}

variable "storage_container_endpoint" {
  description = "Blob container endpoint used by Flex Consumption for package storage."
  type        = string
}

variable "user_assigned_identity_id" {
  description = "User-assigned managed identity resource ID used by the Function App and deployment storage."
  type        = string
}

variable "user_assigned_identity_client_id" {
  description = "Client ID of the user-assigned managed identity attached to the Function App."
  type        = string
}

variable "application_insights_name" {
  description = "Application Insights name."
  type        = string
}

variable "log_analytics_workspace_name" {
  description = "Log Analytics workspace name."
  type        = string
}

variable "functions_extension_version" {
  description = "Azure Functions extension version."
  type        = string
  default     = "~4"
}

variable "function_runtime" {
  description = "Functions worker runtime."
  type        = string
  default     = "python"
}

variable "function_runtime_version" {
  description = "Language runtime version."
  type        = string
  default     = "3.12"
}

variable "maximum_instance_count" {
  description = "Maximum number of Flex Consumption instances."
  type        = number
  default     = 50
}

variable "instance_memory_in_mb" {
  description = "Memory size in MB for each Flex Consumption instance."
  type        = number
  default     = 2048
}

variable "enable_builtin_logging" {
  description = "Whether built in application logging is enabled."
  type        = bool
  default     = false
}

variable "enable_auth" {
  description = "Whether App Service auth is enabled."
  type        = bool
  default     = false
}

variable "auth_client_id" {
  description = "Entra application client ID."
  type        = string
  default     = null
}

variable "auth_client_secret_setting_name" {
  description = "App setting name holding the Entra client secret."
  type        = string
  default     = null
}

variable "auth_allowed_audiences" {
  description = "Allowed token audiences for auth."
  type        = list(string)
  default     = []
}

variable "key_vault_uri" {
  description = "Key Vault URI exposed to the Function App."
  type        = string
  default     = null
}

variable "additional_app_settings" {
  description = "Additional app settings for the Function App."
  type        = map(string)
  default     = {}
}

variable "tags" {
  description = "Resource tags."
  type        = map(string)
  default     = {}
}
