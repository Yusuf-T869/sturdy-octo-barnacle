output "resource_group_name" {
  description = "Existing resource group containing the Terraform state resources."
  value       = data.azurerm_resource_group.tfstate.name
}

output "storage_account_name" {
  description = "Storage account holding Terraform state."
  value       = azurerm_storage_account.tfstate.name
}

output "container_name" {
  description = "Blob container used for Terraform state."
  value       = azurerm_storage_container.tfstate.name
}
