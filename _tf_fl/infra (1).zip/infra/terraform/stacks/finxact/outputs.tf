output "resource_group_name" {
  description = "Resource group containing the Finxact resources."
  value       = data.azurerm_resource_group.main.name
}

output "function_app_name" {
  description = "Name of the deployed Finxact Azure Function App."
  value       = module.function_app.name
}

output "function_app_default_hostname" {
  description = "Default hostname for the Finxact Function App."
  value       = module.function_app.default_hostname
}

output "function_storage_account_name" {
  description = "Storage account used by the Finxact Azure Function runtime."
  value       = module.function_storage.name
}

output "data_storage_account_name" {
  description = "Storage account used for Finxact application data."
  value       = module.data_storage.name
}

# output "container_registry_name" {
#   description = "Name of the Azure Container Registry used by Finxact."
#   value       = module.container_registry.name
# }

# output "container_registry_login_server" {
#   description = "Login server for the Finxact Azure Container Registry."
#   value       = module.container_registry.login_server
# }

# output "container_registry_repository_name" {
#   description = "Repository name referenced by the Finxact Container App image."
#   value       = var.CONTAINER_REGISTRY_REPOSITORY_NAME
# }

# output "container_app_name" {
#   description = "Name of the deployed Finxact Azure Container App."
#   value       = module.container_app.name
# }

# output "container_app_latest_revision_fqdn" {
#   description = "FQDN of the latest Finxact Container App revision."
#   value       = module.container_app.latest_revision_fqdn
# }
