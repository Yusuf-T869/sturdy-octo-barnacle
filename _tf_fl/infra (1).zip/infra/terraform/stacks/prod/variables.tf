# variable "SUBSCRIPTION_ID" {
#   description = "Azure subscription ID. Optional when Terraform should use the current Azure CLI context."
#   type        = string
#   default     = null
#   nullable    = true
# }

variable "AZDO_ORG_SERVICE_URL" {
  description = "Azure DevOps organization URL, for example https://dev.azure.com/example-org."
  type        = string
  default     = null
  nullable    = true
}

variable "AZDO_PERSONAL_ACCESS_TOKEN" {
  description = "Azure DevOps personal access token used by the Terraform provider."
  type        = string
  default     = null
  nullable    = true
  sensitive   = true
}

variable "AZDO_PROJECT_NAME" {
  description = "Existing Azure DevOps project name that will contain the AzureRM service connection."
  type        = string
  default     = null
  nullable    = true
}

variable "TENANT_ID" {
  description = "Azure Entra tenant ID. Optional when Terraform should use the current Azure CLI context."
  type        = string
  default     = null
  nullable    = true
}

variable "RESOURCE_GROUP_NAME" {
  description = "Name of the existing resource group where application resources will be created."
  type        = string
}

variable "ENVIRONMENT" {
  description = "Short environment name, for example dev or prod."
  type        = string
}

variable "LOCATION" {
  description = "Azure region for all regional resources."
  type        = string
}

variable "PROJECT_NAME" {
  description = "Project or workload name used in resource naming."
  type        = string
}

variable "TAGS" {
  description = "Common tags applied to resources."
  type        = map(string)
  default     = {}
}

variable "FUNCTION_STORAGE_ACCOUNT_TIER" {
  description = "Storage account tier used by the Azure Function."
  type        = string
  default     = "Standard"
}

variable "FUNCTION_STORAGE_ACCOUNT_REPLICATION_TYPE" {
  description = "Replication type for the Function App storage account."
  type        = string
  default     = "LRS"
}

variable "BACKEND_STORAGE_ACCOUNT_TIER" {
  description = "Storage account tier used by the application backend storage account."
  type        = string
  default     = "Standard"
}

variable "BACKEND_STORAGE_ACCOUNT_REPLICATION_TYPE" {
  description = "Replication type for the application backend storage account."
  type        = string
  default     = "LRS"
}

variable "SERVICE_PLAN_SKU_NAME" {
  description = "SKU for the Function App service plan."
  type        = string
  default     = "FC1"
}

variable "FUNCTIONS_EXTENSION_VERSION" {
  description = "Azure Functions runtime version."
  type        = string
  default     = "~4"
}

variable "FUNCTION_RUNTIME" {
  description = "Function worker runtime."
  type        = string
  default     = "python"
}

variable "FUNCTION_RUNTIME_VERSION" {
  description = "Language runtime version for the Function App."
  type        = string
  default     = "3.12"
}

variable "FUNCTION_MAXIMUM_INSTANCE_COUNT" {
  description = "Maximum number of Flex Consumption instances."
  type        = number
  default     = 50
}

variable "FUNCTION_INSTANCE_MEMORY_IN_MB" {
  description = "Memory size in MB for each Flex Consumption instance."
  type        = number
  default     = 2048
}

variable "FUNCTION_APP_SETTINGS" {
  description = "Additional Function App settings."
  type        = map(string)
  default     = {}
}

variable "ENABLE_BUILTIN_LOGGING" {
  description = "Whether builtin filesystem logging should be enabled."
  type        = bool
  default     = false
}

variable "ENABLE_AUTH" {
  description = "Whether Azure App Service authentication should be enabled."
  type        = bool
  default     = false
}

variable "AUTH_CLIENT_ID" {
  description = "Client ID for the Entra ID app registration used by Easy Auth."
  type        = string
  default     = null
}

variable "AUTH_CLIENT_SECRET_SETTING_NAME" {
  description = "App setting name that contains the Entra ID client secret."
  type        = string
  default     = null
}

variable "AUTH_ALLOWED_AUDIENCES" {
  description = "Allowed token audiences for Function App auth."
  type        = list(string)
  default     = []
}

variable "KEY_VAULT_SKU_NAME" {
  description = "SKU for Key Vault."
  type        = string
  default     = "standard"
}

variable "KEY_VAULT_PURGE_PROTECTION_ENABLED" {
  description = "Whether purge protection should be enabled on Key Vault."
  type        = bool
  default     = true
}

variable "AZDO_SERVICE_CONNECTION_NAME" {
  description = "Name for the Azure DevOps AzureRM service connection."
  type        = string
  default     = null
  nullable    = true
}

variable "CONTAINER_REGISTRY_NAME" {
  description = "Optional name for the Azure Container Registry. Defaults to a generated name based on the project and environment."
  type        = string
  default     = null
  nullable    = true
}

variable "CONTAINER_REGISTRY_SKU" {
  description = "SKU for the Azure Container Registry."
  type        = string
  default     = "Basic"
}

variable "CONTAINER_REGISTRY_REPOSITORY_NAME" {
  description = "Repository name inside Azure Container Registry used by the Container App image reference."
  type        = string
}

variable "CONTAINER_APP_ENVIRONMENT_NAME" {
  description = "Name of the existing Azure Container Apps environment where the Container App will be deployed."
  type        = string
}

variable "CONTAINER_APP_ENVIRONMENT_RESOURCE_GROUP_NAME" {
  description = "Resource group name of the existing Azure Container Apps environment."
  type        = string
}

variable "CONTAINER_APP_NAME" {
  description = "Optional name for the Container App. Defaults to a generated name based on the project and environment."
  type        = string
  default     = null
  nullable    = true
}

variable "CONTAINER_APP_CONTAINER_NAME" {
  description = "Name of the container inside the Azure Container App."
  type        = string
  default     = "app"
}

variable "CONTAINER_APP_IMAGE" {
  description = "Optional full container image reference. Set this when you are ready to deploy an image from your registry."
  type        = string
  default     = null
  nullable    = true
}

variable "CONTAINER_APP_PLACEHOLDER_IMAGE" {
  description = "Public placeholder image used until the new registry has a real application image available."
  type        = string
  default     = "mcr.microsoft.com/azuredocs/containerapps-helloworld:latest"
}

variable "CONTAINER_APP_IMAGE_TAG" {
  description = "Image tag intended for the future registry-backed application image."
  type        = string
  default     = "latest"
}

variable "CONTAINER_APP_REVISION_MODE" {
  description = "Revision mode for the Container App."
  type        = string
  default     = "Single"
}

variable "CONTAINER_APP_MIN_REPLICAS" {
  description = "Minimum number of replicas for the Container App."
  type        = number
  default     = 1
}

variable "CONTAINER_APP_MAX_REPLICAS" {
  description = "Maximum number of replicas for the Container App."
  type        = number
  default     = 1
}

variable "CONTAINER_APP_CPU" {
  description = "vCPU allocated to the Container App container."
  type        = number
  default     = 0.5
}

variable "CONTAINER_APP_MEMORY" {
  description = "Memory allocated to the Container App container."
  type        = string
  default     = "1Gi"
}

variable "CONTAINER_APP_ENV_VARS" {
  description = "Plain-text environment variables to inject into the Container App container."
  type        = map(string)
  default     = {}
}
