output "resource_group_name" {
  description = "Resource group containing the application resources."
  value       = data.azurerm_resource_group.main.name
}

output "function_app_name" {
  description = "Name of the deployed Azure Function App."
  value       = module.function_app.name
}

output "function_app_default_hostname" {
  description = "Default hostname for the Function App."
  value       = module.function_app.default_hostname
}

output "function_app_uami_name" {
  description = "Name of the user-assigned managed identity used by the Function App."
  value       = azurerm_user_assigned_identity.data_ingest_uami.name
}

output "function_app_uami_principal_id" {
  description = "Principal ID of the user-assigned managed identity used by the Function App."
  value       = azurerm_user_assigned_identity.data_ingest_uami.principal_id
}

output "function_storage_account_name" {
  description = "Storage account used by the Azure Function runtime."
  value       = module.function_storage.name
}

output "backend_storage_account_name" {
  description = "Separate storage account intended for application data."
  value       = module.backend_storage.name
}

output "key_vault_name" {
  description = "Key Vault used by the backend."
  value       = module.key_vault.name
}

output "key_vault_uri" {
  description = "Vault URI for secret retrieval."
  value       = module.key_vault.vault_uri
}

output "container_registry_name" {
  description = "Name of the Azure Container Registry."
  value       = azurerm_container_registry.main.name
}

output "container_registry_login_server" {
  description = "Login server for the Azure Container Registry."
  value       = azurerm_container_registry.main.login_server
}

output "container_registry_repository_name" {
  description = "Repository name referenced by the Container App image."
  value       = var.CONTAINER_REGISTRY_REPOSITORY_NAME
}

output "container_app_name" {
  description = "Name of the deployed Azure Container App."
  value       = azurerm_container_app.main.name
}

output "container_app_latest_revision_fqdn" {
  description = "FQDN of the latest Container App revision."
  value       = azurerm_container_app.main.latest_revision_fqdn
}

output "container_app_environment_id" {
  description = "Resource ID of the existing Container Apps environment used by the Container App."
  value       = data.azurerm_container_app_environment.existing.id
}
